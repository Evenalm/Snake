#ifndef POINT_H
#define POINT_H

class Point
{
   public:
      Point();
      Point(int new_x, int new_y);

      int GetX();
      int GetY();

      void SetX(int x);
      void SetY(int Y);

   private:
      int xCOORD, yCOORD;
      friend bool operator==(Point const& item1, Point const& item2);
};

#endif // POINT_H 
