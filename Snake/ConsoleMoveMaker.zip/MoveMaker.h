#ifndef MoveMaker_H
#define MoveMaker_H

#include "GameState.h"

class MoveMaker
{
   public:
      virtual void MakeMove() = 0;
      virtual GameState MakeMove(GameState state) = 0;
      virtual GameState GetState();
      virtual void SetState(GameState newState);

   protected:
      GameState state;
};

#endif // MoveMaker_H

