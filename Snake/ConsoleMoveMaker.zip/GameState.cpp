#include "GameState.h"

GameState::GameState()
{
   SetDeafultConfig();
}

GameState::GameState(int boardSize)
{
   if (((boardSize % 2) == 1) && boardSize > 3)
   {
      currentPositions.clear();
      currentPositions.emplace_back(0, 1);
      currentPositions.emplace_back(0, 0);

      goalPosition.SetX(boardSize / 2);
      goalPosition.SetY(boardSize / 2);

      this->boardSize = boardSize;
   }
   else
   {
      SetDeafultConfig();
   }
}

GameState::GameState(std::vector<Point> currentPositions, Point goal, int boardSize)
{
   this->currentPositions = currentPositions;
   this->goalPosition = goal;
   this->boardSize = boardSize;
}

GameState GameState::GetNewState(Move nextMove)
{
   Point newHead = Point(this->currentPositions[0].GetX(), this->currentPositions[0].GetY());
   if (nextMove == GameState::Move::Up)
   {
      newHead.SetY(newHead.GetY() + 1);
   }
   else if (nextMove == GameState::Move::Down)
   {
      newHead.SetY(newHead.GetY() - 1);
   }
   else if (nextMove == GameState::Move::Left)
   {
      newHead.SetX(newHead.GetX() - 1);
   }
   else if (nextMove == GameState::Move::Right)
   {
      newHead.SetX(newHead.GetX() + 1);
   }

   this->currentPositions.insert(currentPositions.begin(), newHead);
   if (newHead == goalPosition)
   {
      goalPosition = GetNewGoalPosition();
   }
   else
   {
      this->currentPositions.pop_back();
   }

   return *this;
}

int GameState::GetScore()
{
   return currentPositions.size();
}

bool GameState::IsLegalPosition()
{
   bool positionOutOfBound = true;
   if ((currentPositions[0].GetX() >= boardSize || currentPositions[0].GetX() < 0)
      || (currentPositions[0].GetY() >= boardSize || currentPositions[0].GetY() < 0))
   {
      positionOutOfBound = false;
   }

   bool found = (std::find(currentPositions.begin() + 1, currentPositions.end(), currentPositions[0]) != currentPositions.end());

   return positionOutOfBound && !found;
}

bool GameState::IsGameWon()
{
   return currentPositions.size() >= (boardSize * boardSize);
}

void GameState::SetDeafultConfig()
{
   currentPositions.clear();
   currentPositions.emplace_back(0, 1);
   currentPositions.emplace_back(0, 0);

   goalPosition.SetX(1);
   goalPosition.SetY(1);

   boardSize = 3;
}

Point GameState::GetNewGoalPosition()
{
   if (!IsGameWon())
   {
      std::vector<Point> board;
      for (int ix = 0; ix < boardSize; ix++)
      {
         for (int iy = 0; iy < boardSize; iy++)
         {
            board.emplace_back(ix, iy);
         }
      }

      for (auto const& value : currentPositions)
      {
         board.erase(std::find(board.begin(), board.end(), value));
      }

      int index = (rand() % (int)board.size());
      return board[index];
   }
   return Point(0, 0);
}
