#include <string>
#include "ConsoleView.h"
#include <iostream>

void ConsoleView::displayState(GameState state)
{
   std::vector<std::vector<int>>    board(state.boardSize, std::vector<int>(state.boardSize));
   for (std::vector<Point>::iterator it = state.currentPositions.begin(); it != state.currentPositions.end(); ++it)
   {
      board[(*it).GetX()][(*it).GetY()] = (int)GameState::CellType::body;
   }
   board[state.goalPosition.GetX()][state.goalPosition.GetY()] = (int)GameState::CellType::goal;

   for (int coloum = (state.boardSize - 1); coloum >= 0; --coloum)
   {
      std::string rowRep;
      for (int row = 0; row < state.boardSize; ++row)
      {
         if (board[row][coloum] == (int)GameState::CellType::body)
         {
            rowRep.append("S\t");
         }
         else if (board[row][coloum] == (int)GameState::CellType::goal)
         {
            rowRep.append("F\t");
         }
         else
         {
            rowRep.append("[]\t");
         }
      }
      rowRep.append("\n");
      std::cout << rowRep;
   }

}

void ConsoleView::displayMessage(std::string s)
{
   std::cout << s;
}

void ConsoleView::displayWinningMessage(GameState state)
{
   std::cout << "You Won!";
}

void ConsoleView::displayLosingMessage(GameState state)
{
   std::cout << "You lost, your score: " << state.GetScore();
}
