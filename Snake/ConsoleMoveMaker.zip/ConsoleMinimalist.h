#ifndef ConsoleMinimalist_H
#define ConsoleMinimalist_H

#include "MoveMaker.h"

class ConsoleMinimalist : public MoveMaker
{
   public:
      ConsoleMinimalist();
      virtual void MakeMove() override;
      virtual GameState MakeMove(GameState state) override;

   private:
      GameState updateState(GameState state);
};

#endif // ConsoleMinimalist_H