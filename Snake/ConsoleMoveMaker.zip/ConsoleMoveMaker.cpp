#include <iostream>
#include <string>
#include "ConsoleMoveMaker.h"
#include "GameState.h"

ConsoleMoveMaker::ConsoleMoveMaker()
{
   state = GameState();
}

void ConsoleMoveMaker::MakeMove()
{
   state = updateState(this->state);
}

GameState ConsoleMoveMaker::MakeMove(GameState state)
{
   return updateState(state);
}

GameState ConsoleMoveMaker::updateState(GameState state)
{
   std::string mystr;
   std::cout << "Make next move (u,d,l,r) \n";
   getline(std::cin, mystr);
   std::cout << "\n";

   if (mystr.find("l") != std::string::npos)
   {
      state = state.GetNewState(GameState::Move::Left);
   }
   else if (mystr.find("r") != std::string::npos)
   {
      state = state.GetNewState(GameState::Move::Right);
   }
   else if (mystr.find("d") != std::string::npos)
   {
      state = state.GetNewState(GameState::Move::Down);
   }
   else
   {
      state = state.GetNewState(GameState::Move::Up);
   }

   return state;
}
