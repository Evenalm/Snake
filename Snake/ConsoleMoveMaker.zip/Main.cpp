#include <iostream>
#include <time.h>
#include "MoveMaker.h"
#include "ConsoleMoveMaker.h"
#include "ConsoleMinimalist.h"
#include "ConsoleView.h"

int main()
{
   srand((unsigned)time(NULL));
   MoveMaker* input = new ConsoleMinimalist();
   input->SetState(GameState(3));
   Viewer* output = new ConsoleView();


   do {
      output->displayState(input->GetState());
      input->MakeMove();
   } while (input->GetState().IsLegalPosition() && !input->GetState().IsGameWon());


   if (input->GetState().IsGameWon())
   {
      output->displayWinningMessage(input->GetState());
   }
   else
   {
      output->displayLosingMessage(input->GetState());
   }

   delete input;
   delete output;
}
