#ifndef GameState_H
#define GameState_H

#include <vector>
#include "Point.h"

class GameState
{
   public:
      enum class Move { Up, Left, Right, Down };
      enum class CellType { open = 0, body = 1, goal = 2 };

      GameState();
      GameState(int boardSize);
      GameState(std::vector<Point> currentPositions, Point goal, int boardSize);

      GameState GetNewState(Move nextMove);
      int GetScore();
      bool IsLegalPosition();
      bool IsGameWon();

      Point goalPosition;
      std::vector<Point> currentPositions;
      int boardSize;

   private:
      void SetDeafultConfig();
      Point GetNewGoalPosition();
};

#endif // GameState_H