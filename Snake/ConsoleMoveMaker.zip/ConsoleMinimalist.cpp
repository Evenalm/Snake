#include <iostream>
#include <string>
#include "ConsoleMinimalist.h"

ConsoleMinimalist::ConsoleMinimalist()
{
   state = GameState();
}

void ConsoleMinimalist::MakeMove()
{
   state = updateState(this->state);
}

GameState ConsoleMinimalist::MakeMove(GameState state)
{
   return updateState(state);
}

GameState ConsoleMinimalist::updateState(GameState state)
{
   std::string mystr;
   std::cout << "Make next move (u,l,r) \n";
   getline(std::cin, mystr);
   std::cout << "\n";

   if (mystr.find("l") != std::string::npos)
   {
      if (state.currentPositions[0].GetX() == state.currentPositions[1].GetX())
      {
         if (state.currentPositions[0].GetY() > state.currentPositions[1].GetY())
         {
            state = state.GetNewState(GameState::Move::Left);
         }
         else
         {
            state = state.GetNewState(GameState::Move::Right);
         }
      }
      else
      {
         if (state.currentPositions[0].GetX() > state.currentPositions[1].GetX())
         {
            state = state.GetNewState(GameState::Move::Up);
         }
         else
         {
            state = state.GetNewState(GameState::Move::Down);
         }
      }
   }
   else if (mystr.find("r") != std::string::npos)
   {
      if (state.currentPositions[0].GetX() == state.currentPositions[1].GetX())
      {
         if (state.currentPositions[0].GetY() > state.currentPositions[1].GetY())
         {
            state = state.GetNewState(GameState::Move::Right);
         }
         else
         {
            state = state.GetNewState(GameState::Move::Left);
         }
      }
      else
      {
         if (state.currentPositions[0].GetX() > state.currentPositions[1].GetX())
         {
            state = state.GetNewState(GameState::Move::Down);
         }
         else
         {
            state = state.GetNewState(GameState::Move::Up);
         }
      }
   }
   else
   {
      if (state.currentPositions[0].GetX() == state.currentPositions[1].GetX())
      {
         if (state.currentPositions[0].GetY() > state.currentPositions[1].GetY())
         {
            state = state.GetNewState(GameState::Move::Up);
         }
         else
         {
            state = state.GetNewState(GameState::Move::Down);
         }
      }
      else
      {
         if (state.currentPositions[0].GetX() > state.currentPositions[1].GetX())
         {
            state = state.GetNewState(GameState::Move::Right);
         }
         else
         {
            state = state.GetNewState(GameState::Move::Left);
         }
      }
   }

   return state;
}
