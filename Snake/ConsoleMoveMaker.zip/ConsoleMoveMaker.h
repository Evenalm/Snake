#ifndef ConsoleMoveMaker_H
#define ConsoleMoveMaker_H

#include "MoveMaker.h"

class ConsoleMoveMaker : public MoveMaker
{
   public:
      ConsoleMoveMaker();
      virtual void MakeMove() override;
      virtual GameState MakeMove(GameState state) override;

   private:
      GameState updateState(GameState state);
};

#endif // ConsoleMoveMaker_H

