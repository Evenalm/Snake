#include "point.h"

Point::Point() :xCOORD(0), yCOORD(0)
{
}

Point::Point(int new_x, int new_y)
{
   xCOORD = new_x;
   yCOORD = new_y;
}

void Point::SetX(int x)
{
   xCOORD = x;
}

void Point::SetY(int y)
{
   yCOORD = y;
}

int Point::GetX()
{
   return xCOORD;
}

int Point::GetY()
{
   return yCOORD;
}

bool operator==(Point const& item1, Point const& item2)
{
   return (item1.xCOORD == item2.xCOORD) && (item1.yCOORD == item2.yCOORD);
}
