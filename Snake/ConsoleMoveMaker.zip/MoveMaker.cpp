#include "MoveMaker.h"

GameState MoveMaker::GetState()
{
   return this->state;
}

void MoveMaker::SetState(GameState newState)
{
   this->state = newState;
}
